//var WEBSOCKET_SERVER = "ws://127.0.0.1:9000/royale/ws";
var WEBSOCKET_SERVER = "ws://marioroyale.cyuubi.gq:9000/royale/ws";
print("loading server.js finished");
