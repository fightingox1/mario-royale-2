var LOBBY_MUSIC_URL = "audio/music/lobby.mp3";
var MENU_MUSIC_URL = "audio/music/menu.mp3";
var SKIN_MUSIC_URL = {
    6: "audio/music/sonic.mp3?v=3",
    7: "audio/music/tails.mp3",
    8: "audio/music/knuckles.mp3?v=2",
    9: "audio/music/megaman.mp3",
    10: "audio/music/link.mp3",
    11: "audio/music/frisk.mp3",
    12: "audio/music/steve.mp3",
    13: "audio/music/pepsi.mp3",
    14: "audio/music/catmario.mp3",
    15: "audio/music/roblox.mp3",
    16: "audio/music/bowsette.mp3",
    17: "audio/music/hellokitty.mp3",
    18: "audio/music/sans.mp3",
    19: "audio/music/shrek.mp3?v=2",
    20: "audio/music/spiderman.mp3",
    21: "audio/music/chara.mp3",
    22: "audio/music/castlevania.mp3",
    23: "audio/music/kirby.mp3",
    24: "audio/music/ducktales.mp3",
    25: "audio/music/doom.mp3",
    26: "audio/music/toriel.mp3",
    27: "audio/music/waluigi.mp3",
    28: "audio/music/pedro.mp3",
    29: "audio/music/duck.mp3",
    30: "audio/music/et.mp3",
    31: "audio/music/bbmario.mp3",
    32: "audio/music/gnw.mp3"
};
print("loading url.js finished");