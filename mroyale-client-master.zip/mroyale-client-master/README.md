# PyRoyaleClient
This repository is only for the development of the Mario Royale client source code.
I'm not the writer of Mario Royale, the initial version 2.1.0A was a backup from InfernoPlus' website that I deobfuscated.

Want to help us? Just create a Pull Request!
